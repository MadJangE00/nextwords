export default function Notice() {
    return (
        <div>
            <h1>Notice</h1>
        </div>
    );
}